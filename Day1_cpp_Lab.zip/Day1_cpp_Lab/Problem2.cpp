#include<iostream>
using namespace std;
int main22(){
	int n1,n2,n3;
	cout<<"Enter num1="<<endl;
	cin>>n1;
	cout<<"Enter num2="<<endl;
	cin>>n2;
	cout<<"Enter num3="<<endl;
	cin>>n3;
	 if(n1>n2 &&n1>n3){
	 	cout<<"n1 is maximum"<<endl;
	 }
	 else if(n2>n1 &&n2>n3){
	 	cout<<"n2 is maximum"<<endl;
	 }
	 else{
	 		cout<<"n3 is maximum"<<endl;
	 }
	 return 0;
}
