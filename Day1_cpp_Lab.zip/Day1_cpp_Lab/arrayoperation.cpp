#include<iostream>
using namespace std;

void displayGreatest(int* arr,int n){
	int maxi=arr[0];
	for(int i=0;i<n;i++){
		if(arr[i]>maxi){
			maxi=arr[i];
		}
	}
	cout<<"Greatest Number in array is : "<<maxi<<endl;
}

void displayEven(int* arr, int n){
	for(int i=0;i<n;i++){
		if(arr[i]%2==0){
			cout<<arr[i]<<" ";
		}
	}
	cout<<endl;
}

void displaySum(int *arr,int n){
	int sum=0;
	for(int i=0;i<n;i++){
		sum=sum+arr[i];
	}
	cout<<"Sum of all elements is : "	<<sum<<endl;
}

void searchElement(int *arr, int n, int key){
	for(int i=0;i<n;i++){
		if(key == arr[i]){
			cout<<"Element found at index : "	<<i<<endl;
		}
	}
	cout<<"Element not found"<<endl;
}


void arrayOperations(){
	int *arr;
	int n;
	cout<<"Enter the size of array : ";
	cin>>n;
	arr = new int[n];
	for(int i=0;i<n;i++){
		cin>> arr[i];
	}
	bool flag = true;
	
	do{
		cout<<"\n\n\n1. Display Greatest Num. \n2. Display Even Numbers."<<endl
		 	<<"3. Sum of array elements.\n"
			<<"4. Searching Elements. \n 5. Enter 5 to exit"<<endl<<endl;
		int choice;
		cout<<"Enter your choice : "<<endl;
		cin>> choice;
		
		switch(choice){
			case 1:
				displayGreatest(arr,n);
				break;
			case 2:
				displayEven(arr,n);
				break;
			case 3:
				displaySum(arr,n);
				break;
			case 4:
				cout<<"Enter the element to search: "<<endl;
				int t;
				cin>>t;
				searchElement(arr,n,t);
				break;
			case 5:
				flag= false;
				break;
			default:
				break;
		}
		
	}while(flag);
}


int main5(){
	arrayOperations();
}
