#include<iostream>
using namespace std;

void oddNum()
{
	cout<<"Odd numbers from 1 to 50 are : "<<endl;
	for(int i=1;i<51;i++){
		if(i%2==1){
			cout<<i<<" ";
		}
	}
		cout<<endl<< endl;
		cout<<"--------------------------------------------------------"<<endl;
}

void primeNum()
{
	int n;
	cout<<"Enter a Number to check if it is prime or not."<<endl;
	cin>>n;
	bool flag=true;
	for(int i=1;i<n;i++){
		if(i%n==0){
			cout<<"The given number is Not a Prime"<<endl;
			flag=false;
			break;

		}
	}
	if(flag==true){
		cout<<"The given number is Prime Number"<<endl;
	}
		cout<<endl<< endl;
		cout<<"--------------------------------------------------------"<<endl;
}

void displayNums(){
	int i=100;
	while(i>0){
		cout<<i<<" ";
		i=i-1;
	}
	cout<<endl;
		cout<<endl<< endl;
		cout<<"--------------------------------------------------------"<<endl;
}
int main11(){
	oddNum();
	primeNum();
	displayNums();
	
	return 0;
}
