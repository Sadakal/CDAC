#include<iostream>
using namespace std;

void displayMonth(){
	bool flag = true;
	do{
		cout<<"Enter the month number : \nEnter any other number to exit."<<endl;
		int c ;
		cin>> c;
		switch(c){
			case 1:
				cout<<"January"<<endl;
				break;
			case 2:
				cout<<"febuary"<<endl;
				break;
			case 3:
				cout<<"March"<<endl;
				break;
			case 4:
				cout<<"april"<<endl;
				break;
			case 5:
				cout<<"may"<<endl;
				break;
			case 6:
				cout<<"June"<<endl;
				break;
			case 7:
				cout<<"July"<<endl;
				break;
			case 8:
				cout<<"August"<<endl;
				break;
			case 9:
				cout<<"Sept"<<endl;
				break;
			default:
				cout<<"Invalid choice"<<endl;
				flag = false;
				break;
			
		}
		
	}while(flag);
	
	
	
}

int main1(){

	displayMonth();
	
	
	
	return 0;
}
