#include<iostream>
using namespace std;

void evenOdd(){
	bool flag = true;
	while(flag){
		int num;
		cout<<"Enter the num : "<<endl;
		cout<<"Enter 0 to exit."<<endl;
		cin>>num;
		if(num == 0) {
			flag = false;
			break;
		}
		if(num%2==0){
			cout<<"Even number "<<endl;
		}
		else{
			cout<<"Odd number"<<endl;
		}
	}
}

int main12(){
	
	evenOdd();
	return 0;
	
}
